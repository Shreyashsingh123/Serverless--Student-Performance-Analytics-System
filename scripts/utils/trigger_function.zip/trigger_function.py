import csv
import boto3
from dotenv import load_dotenv
from decimal import Decimal
import os
load_dotenv()

s3=boto3.client('s3')
dynamodb=boto3.resource('dynamodb')
table=dynamodb.Table('student-performance')

def lambda_function(event,context):
    bucket=event['Records'][0]['s3']['bucket']['name']
    key=event['Records'][0]['s3']['object']['name']

    obj=s3.get_obj(Bucket=bucket,Key=key)
    line=obj['Body'].read().decode('utf-8').splitlines()
    reader=csv.DictReader(line)

    for row in reader:
        total_score=Decimal(row['total_score']).quantize(Decimal('0.00'))

        if total_score>Decimal('90.00'):
            performance_category="Excellent"
        elif total_score >=Decimal('75.00') and total_score<=Decimal('89.00'):
            performance_category="Good"
        elif total_score >=Decimal('60.00') and total_score<=Decimal('74.00'):
            performance_category="Average"
        else:
            performance_category="Poor"
        
        table.put_Item(
            Item={'student_id': int(row['student_id']),
                    'weekly_self_study_hours': int(row['weekly_self_study_hours']),
                    'attendance_percentage': int(row['attendance_percentage']),
                    'class_participation': int(row['class_participation']),
                    'total_score': total_score,
                    'grade': row['grade'],
                    'performance_category':performance_category
            }
        )
